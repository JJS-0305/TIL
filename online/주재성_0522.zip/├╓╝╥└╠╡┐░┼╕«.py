import heapq
import sys
sys.stdin = open('최소이동거리_input.txt')

def dijkstar():
    dist = [float('inf')] * (V + 1)
    dist[0] = 0
    pq = []
    pq.append((0, 0))
    heapq.heapify(pq)

    while pq:
        cost, st = heapq.heappop(pq)

        for ed, w in adj[st]:
            via = w + dist[st]
            if dist[ed] > via:
                dist[ed] = via
                heapq.heappush(pq, (via, ed))

    return dist[-1]

T = int(input())

for tc in range(1, T+1):
    V, E = map(int,input().split())
    adj = [[] for _ in range(V+1)]

    for _ in range(E):
        s, e, w = map(int,input().split())
        adj[s].append((e, w))

    print("#{} {}".format(tc,dijkstar()))